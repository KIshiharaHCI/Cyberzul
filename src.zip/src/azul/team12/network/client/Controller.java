package azul.team12.network.client;

public class Controller {
}
