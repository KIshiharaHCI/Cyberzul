package azul.team12.model.events;

public class NoValidTurnToMakeEvent extends GameEvent {

  @Override
  public String getName() {
    return "NoValidTurnToMakeEvent";
  }

}
