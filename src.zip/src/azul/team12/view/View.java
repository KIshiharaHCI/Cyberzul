package azul.team12.view;

public interface View {
}
